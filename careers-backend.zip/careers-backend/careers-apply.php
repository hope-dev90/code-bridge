<?php
/**
 * Handles job application submissions from application.html.
 * Stores the application in MySQL and saves any uploaded CV / cover
 * letter to uploads/careers/ (which is not web-listable — see its .htaccess).
 */

require __DIR__ . '/db_config.php';

header('Content-Type: application/json');

function fail(string $message, int $code = 400): void
{
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('Method not allowed.', 405);
}

// Honeypot — real visitors never fill this hidden field in.
if (!empty($_POST['website'] ?? '')) {
    echo json_encode(['success' => true]); // pretend success, drop silently
    exit;
}

$required = ['position', 'full_name', 'email', 'phone'];
foreach ($required as $field) {
    if (trim($_POST[$field] ?? '') === '') {
        fail("Missing required field: {$field}");
    }
}

$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
if (!$email) {
    fail('Please provide a valid email address.');
}

function str_field(string $key, int $maxLen = 255): ?string
{
    $val = trim($_POST[$key] ?? '');
    if ($val === '') {
        return null;
    }
    return mb_substr($val, 0, $maxLen);
}

function int_field(string $key): ?int
{
    $val = trim($_POST[$key] ?? '');
    return ($val !== '' && ctype_digit($val)) ? (int) $val : null;
}

$uploadDir = dirname(__DIR__) . '/uploads/careers/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$allowedExt = ['pdf', 'doc', 'docx'];
$maxBytes = 5 * 1024 * 1024; // 5MB

function store_upload(string $inputName, string $uploadDir, array $allowedExt, int $maxBytes): ?string
{
    if (empty($_FILES[$inputName]) || $_FILES[$inputName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $file = $_FILES[$inputName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        fail('File upload failed for ' . $inputName . '.');
    }
    if ($file['size'] > $maxBytes) {
        fail('File too large (max 5MB): ' . $inputName);
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        fail('Unsupported file type for ' . $inputName . '. Use PDF, DOC or DOCX.');
    }
    $storedName = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $storedName)) {
        fail('Could not save uploaded file: ' . $inputName);
    }
    return $storedName;
}

$cvFilename = store_upload('cv', $uploadDir, $allowedExt, $maxBytes);
$coverLetterFilename = store_upload('cover_letter', $uploadDir, $allowedExt, $maxBytes);

$dob = str_field('date_of_birth', 10);
if ($dob !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
    $dob = null;
}

$conn = careers_db();
$stmt = $conn->prepare(
    'INSERT INTO codebridge_job_applications
        (position, full_name, email, phone, company, date_of_birth, location, linkedin_url,
         institution1, degree1, field_of_study1, graduation_year1,
         institution2, degree2, skills, note, cv_filename, cover_letter_filename)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
);
if (!$stmt) {
    fail('Could not prepare application for saving.', 500);
}

$position = str_field('position', 120);
$fullName = str_field('full_name', 150);
$phone = str_field('phone', 40);
$company = str_field('company', 150);
$location = str_field('location', 150);
$linkedin = str_field('linkedin_url', 255);
$institution1 = str_field('institution1', 190);
$degree1 = str_field('degree1', 100);
$field1 = str_field('field_of_study1', 150);
$gradYear1 = int_field('graduation_year1');
$institution2 = str_field('institution2', 190);
$degree2 = str_field('degree2', 100);
$skills = str_field('skills', 400);
$note = str_field('note', 4000);

// 11 string params, 1 int (graduation_year1), then 6 more string params — built
// programmatically rather than hand-counted to avoid a mismatched type string.
$types = str_repeat('s', 11) . 'i' . str_repeat('s', 6);
$stmt->bind_param(
    $types,
    $position, $fullName, $email, $phone, $company, $dob, $location, $linkedin,
    $institution1, $degree1, $field1, $gradYear1,
    $institution2, $degree2, $skills, $note, $cvFilename, $coverLetterFilename
);

if (!$stmt->execute()) {
    fail('Could not save application. Please try again.', 500);
}

echo json_encode(['success' => true]);
