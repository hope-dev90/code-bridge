<?php
/**
 * Credentials for careers-admin.php.
 * CHANGE THIS PASSWORD after your first login — see the note handed to you
 * alongside this file. To set a new one: compute sha256("your-new-password")
 * and paste the hex digest below as ADMIN_PASSWORD_SHA256.
 */

const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD_SHA256 = '408b9af82456e85d5b165dc51ff467eb6cdb8556fe5e92a49e6457dc5897a620';
